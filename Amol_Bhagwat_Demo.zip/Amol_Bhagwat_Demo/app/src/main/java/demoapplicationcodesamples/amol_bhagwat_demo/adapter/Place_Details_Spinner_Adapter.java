package demoapplicationcodesamples.amol_bhagwat_demo.adapter;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

import demoapplicationcodesamples.amol_bhagwat_demo.R;
import demoapplicationcodesamples.amol_bhagwat_demo.pojo.Place_Details;


public class Place_Details_Spinner_Adapter extends ArrayAdapter<Place_Details> {

    private List<Place_Details> place_detailsList;

    public Place_Details_Spinner_Adapter(Context context, List<Place_Details> place_detailsList) {
        super(context, R.layout.spinner_item, place_detailsList);
        this.place_detailsList=place_detailsList;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        return initView(position, convertView);
    }

    @Override
    public View getDropDownView(int position, View convertView,
                                ViewGroup parent) {
        return initView(position, convertView);
    }

    private View initView(int position, View convertView) {

        if(convertView == null)
            convertView = View.inflate(getContext(),
                    R.layout.spinner_item,
                    null);

        TextView spinnerText = (TextView)convertView.findViewById(R.id.spinnertext);
        spinnerText.setText(place_detailsList.get(position).getName());

        return convertView;
    }
}
