package demoapplicationcodesamples.amol_bhagwat_demo.fragment;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import demoapplicationcodesamples.amol_bhagwat_demo.R;

public class Fragment_Controller_Point1 extends Fragment {

    private int fragment_position;

    public static Fragment_Controller_Point1 newInstance(int position) {
        Fragment_Controller_Point1 f = new Fragment_Controller_Point1();
        Bundle args = new Bundle();
        args.putInt("position", position);
        f.setArguments(args);
        return f;
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            Bundle bundle=getArguments();
            fragment_position = bundle.getInt("position");
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        int layout_id;

        //Attach different fragments as per sequence

        switch (fragment_position) {
            case 0:
                layout_id = R.layout.fragment1;
                break;

            case 1:
                layout_id = R.layout.fragment2;
                break;

            case 2:
                layout_id = R.layout.fragment3;
                break;

            case 3:
                layout_id = R.layout.fragment4;
                break;

            default:
                layout_id = R.layout.fragment4;
                break;
        }

        View page = inflater.inflate(layout_id, container, false);

        page.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Toast.makeText(getActivity(),fragment_position+" Position Fragment was clicked: ",Toast.LENGTH_SHORT).show();
            }
        });

        return page;
    }

}
