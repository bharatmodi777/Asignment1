package demoapplicationcodesamples.amol_bhagwat_demo.fragment;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;

import demoapplicationcodesamples.amol_bhagwat_demo.R;
import demoapplicationcodesamples.amol_bhagwat_demo.adapter.Recycler_Item_Adapter_Point1;
import demoapplicationcodesamples.amol_bhagwat_demo.adapter.ViewPagerAdapter_Point2;
import demoapplicationcodesamples.amol_bhagwat_demo.modal.assignment1.RecyclerItemClickListener;


public class Assignment1_Fragment extends Fragment implements View.OnClickListener{

    private View rootView;
    private Button red_button,green_button,blue_button;
    private RecyclerView recyclerView;
    private LinearLayout point_4_l_layout;
    private ViewPager viewPager_point2;
    private TextView textView_item;
    private View indicator1;
    private View indicator2;
    private View indicator3;
    private View indicator4;
    private ArrayList<String> itemList;
    private int indicator_largesize=10,indicator_smallsize=5;

    public static Assignment1_Fragment newInstance() {
        Assignment1_Fragment fragment = new Assignment1_Fragment();
        Bundle args = new Bundle();

        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {

        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        rootView=inflater.inflate(R.layout.fragment_assignment1, container, false);

        return rootView;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        initializeView();

    }

    private void initializeView() {

        //Intialize items for point1
        itemList=new ArrayList<>();
        itemList.add("Item1");
        itemList.add("Item2");
        itemList.add("Item3");
        itemList.add("Item4");
        itemList.add("Item5");
        itemList.add("Item6");

        //Intialize wigets of assignment1 screen
        textView_item= (TextView)rootView.findViewById(R.id.textView_item);

        point_4_l_layout = (LinearLayout)rootView.findViewById(R.id.point_4_l_layout);

        red_button = (Button)rootView.findViewById(R.id.red_button);
        green_button = (Button)rootView.findViewById(R.id.green_button);
        blue_button = (Button)rootView.findViewById(R.id.blue_button);

        red_button.setOnClickListener(this);
        green_button.setOnClickListener(this);
        blue_button.setOnClickListener(this);


        //Intialize RecyclerView point1

        recyclerView = (RecyclerView)rootView.findViewById(R.id.recycle_view);
        LinearLayoutManager layoutManager
                = new LinearLayoutManager(getActivity(), LinearLayoutManager.HORIZONTAL, false);
        recyclerView.setLayoutManager(layoutManager);

        Recycler_Item_Adapter_Point1 adapter = new Recycler_Item_Adapter_Point1(getActivity(),itemList);
        recyclerView.setAdapter(adapter);

        recyclerView.setItemAnimator(new DefaultItemAnimator());

        recyclerView.addOnItemTouchListener(
                new RecyclerItemClickListener(getActivity(), new RecyclerItemClickListener.OnItemClickListener() {
                    @Override public void onItemClick(View view, int position) {

                        textView_item.setText(itemList.get(position));
                    }
                })
        );

        //Intialize RecyclerView point2
        viewPager_point2 = (ViewPager) rootView.findViewById(R.id.viewPager);
        indicator1 = (View) rootView.findViewById(R.id.indicator1);
        indicator2 = (View) rootView.findViewById(R.id.indicator2);
        indicator3 = (View) rootView.findViewById(R.id.indicator3);
        indicator4 = (View) rootView.findViewById(R.id.indicator4);

        viewPager_point2 = (ViewPager) rootView.findViewById(R.id.viewPager);

        viewPager_point2.setAdapter(new ViewPagerAdapter_Point2(getActivity().getSupportFragmentManager()));
        viewPager_point2.addOnPageChangeListener(new Item_PageChangeListener());

        //Set Indicator to 0 location i.e in point2
        updateIndicators(0);

    }

    @Override
    public void onDetach() {
        super.onDetach();
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.red_button:
                point_4_l_layout.setBackgroundColor(ContextCompat.getColor(getActivity(), android.R.color.holo_red_dark));
                break;

            case R.id.green_button:
                point_4_l_layout.setBackgroundColor(ContextCompat.getColor(getActivity(), android.R.color.holo_green_dark));

                break;

            case R.id.blue_button:
                point_4_l_layout.setBackgroundColor(ContextCompat.getColor(getActivity(), android.R.color.holo_blue_dark));

                break;
        }


    }


    private class Item_PageChangeListener implements ViewPager.OnPageChangeListener {

        @Override
        public void onPageScrollStateChanged(int position) {
            // TODO Auto-generated method stub

        }

        @Override
        public void onPageScrolled(int position, float positionOffset,
                                   int positionOffsetPixels) {
            // TODO Auto-generated method stub

        }

        @Override
        public void onPageSelected(int position) {
            updateIndicators(position);
        }

    }


    public void updateIndicators(int position) {

        DisplayMetrics metrics = getResources().getDisplayMetrics();
        int resizeValue = (int) TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP, indicator_largesize, metrics);
        int defaultValue = (int) TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP, indicator_smallsize, metrics);

        switch (position) {
            case 0:
                indicator1.getLayoutParams().height = resizeValue;
                indicator1.getLayoutParams().width = resizeValue;
                indicator1.requestLayout();

                indicator2.getLayoutParams().height = defaultValue;
                indicator2.getLayoutParams().width = defaultValue;
                indicator2.requestLayout();

                indicator3.getLayoutParams().height = defaultValue;
                indicator3.getLayoutParams().width = defaultValue;
                indicator3.requestLayout();

                indicator4.getLayoutParams().height = defaultValue;
                indicator4.getLayoutParams().width = defaultValue;
                indicator4.requestLayout();

                break;

            case 1:
                indicator1.getLayoutParams().height = defaultValue;
                indicator1.getLayoutParams().width = defaultValue;
                indicator1.requestLayout();

                indicator2.getLayoutParams().height = resizeValue;
                indicator2.getLayoutParams().width = resizeValue;
                indicator2.requestLayout();

                indicator3.getLayoutParams().height = defaultValue;
                indicator3.getLayoutParams().width = defaultValue;
                indicator3.requestLayout();

                indicator4.getLayoutParams().height = defaultValue;
                indicator4.getLayoutParams().width = defaultValue;
                indicator4.requestLayout();
                break;

            case 2:
                indicator1.getLayoutParams().height = defaultValue;
                indicator1.getLayoutParams().width = defaultValue;
                indicator1.requestLayout();

                indicator2.getLayoutParams().height = defaultValue;
                indicator2.getLayoutParams().width = defaultValue;
                indicator2.requestLayout();

                indicator3.getLayoutParams().height = resizeValue;
                indicator3.getLayoutParams().width = resizeValue;
                indicator3.requestLayout();

                indicator4.getLayoutParams().height = defaultValue;
                indicator4.getLayoutParams().width = defaultValue;
                indicator4.requestLayout();
                break;

            case 3:
                indicator1.getLayoutParams().height = defaultValue;
                indicator1.getLayoutParams().width = defaultValue;
                indicator1.requestLayout();

                indicator2.getLayoutParams().height = defaultValue;
                indicator2.getLayoutParams().width = defaultValue;
                indicator2.requestLayout();

                indicator3.getLayoutParams().height = defaultValue;
                indicator3.getLayoutParams().width = defaultValue;
                indicator3.requestLayout();

                indicator4.getLayoutParams().height = resizeValue;
                indicator4.getLayoutParams().width = resizeValue;
                indicator4.requestLayout();
                break;
        }

    }

}
