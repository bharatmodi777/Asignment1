package demoapplicationcodesamples.amol_bhagwat_demo.adapter;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

import demoapplicationcodesamples.amol_bhagwat_demo.fragment.Fragment_Controller_Point1;

public class ViewPagerAdapter_Point2 extends FragmentPagerAdapter {

    private int fragment_count = 4;

    public ViewPagerAdapter_Point2(FragmentManager fm) {
        super(fm);
    }

    @Override
    public Fragment getItem(int position) {
        return Fragment_Controller_Point1.newInstance(position);
    }

    @Override
    public int getCount() {
        return fragment_count;
    }


}