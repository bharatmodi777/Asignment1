package demoapplicationcodesamples.amol_bhagwat_demo.util;


public class Fragment_Tags_Constant {

    public  static  final int Map_Fragment=1;

}
