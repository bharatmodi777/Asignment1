package demoapplicationcodesamples.amol_bhagwat_demo.modal;

import demoapplicationcodesamples.amol_bhagwat_demo.pojo.Map_Fragment_Info;

public interface OnCustomFragmentInteractionListener
{
    public void onFragmentInteraction(int fragmentID,Map_Fragment_Info map_fragment_info);
}
