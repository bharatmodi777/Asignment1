package demoapplicationcodesamples.amol_bhagwat_demo.fragment;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import demoapplicationcodesamples.amol_bhagwat_demo.R;
import demoapplicationcodesamples.amol_bhagwat_demo.pojo.Map_Fragment_Info;


public class Map_Fragment extends Fragment{

    private GoogleMap map;
    private Double lat_double,long_double;
    private View rootView;
    private Map_Fragment_Info map_fragment_info;
    private float zoom=15,  tilt=10,  bearing=0;


    public static Map_Fragment newInstance(Map_Fragment_Info map_fragment_info) {
        Map_Fragment fragment = new Map_Fragment();
        Bundle args = new Bundle();
        args.putSerializable("map_fragment_info", map_fragment_info);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            Bundle bundle=getArguments();
            map_fragment_info = (Map_Fragment_Info)bundle.getSerializable("map_fragment_info");
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        rootView=inflater.inflate(R.layout.fragment_map, container, false);

        return rootView;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        initializeView();
    }

    @Override
    public void onDetach() {
        super.onDetach();
    }


    private void initializeView() {
        if (map == null) {
            map = ((SupportMapFragment) getChildFragmentManager().findFragmentById(R.id.map)).getMap();

            map.setMapType(GoogleMap.MAP_TYPE_NORMAL);
            // check if map is created successfully or not
            map.setMyLocationEnabled(true);

            if(map_fragment_info!=null)
            {
                lat_double = Double.valueOf(map_fragment_info.getLatitude());
                long_double = Double.valueOf(map_fragment_info.getLongitude());


                map.addMarker(new MarkerOptions()
                        .position(new LatLng(lat_double, long_double))
                        .title(map_fragment_info.getName())
                        .icon(BitmapDescriptorFactory.fromResource(R.drawable.track)));

                map.animateCamera(CameraUpdateFactory.newCameraPosition(new CameraPosition(new LatLng(lat_double, long_double), zoom, tilt,bearing)));
            }
        }
    }
}
