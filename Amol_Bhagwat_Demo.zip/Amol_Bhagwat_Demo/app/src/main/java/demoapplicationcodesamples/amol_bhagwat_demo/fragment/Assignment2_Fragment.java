package demoapplicationcodesamples.amol_bhagwat_demo.fragment;


import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

import demoapplicationcodesamples.amol_bhagwat_demo.R;
import demoapplicationcodesamples.amol_bhagwat_demo.adapter.Place_Details_Spinner_Adapter;
import demoapplicationcodesamples.amol_bhagwat_demo.modal.OnCustomFragmentInteractionListener;
import demoapplicationcodesamples.amol_bhagwat_demo.pojo.Map_Fragment_Info;
import demoapplicationcodesamples.amol_bhagwat_demo.pojo.Place_Details;
import demoapplicationcodesamples.amol_bhagwat_demo.util.Fragment_Tags_Constant;


public class Assignment2_Fragment extends Fragment implements View.OnClickListener{

    private View rootView;
    private List<Place_Details> place_detailsList;
    private ProgressBar progressBar;
    private Spinner spinner_place_selection;
    private Button button_navigate;
    private RelativeLayout parentView;
    private TextView textView_car_val,textView_train_val;
    private OnCustomFragmentInteractionListener mListener;
    private int selectedItem_spinner_place;

    public static Assignment2_Fragment newInstance() {
        Assignment2_Fragment fragment = new Assignment2_Fragment();
        Bundle args = new Bundle();

        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        try {
            mListener = (OnCustomFragmentInteractionListener) context;
        } catch (ClassCastException e) {
            throw new ClassCastException(context.toString()
                    + " must implement OnCustomFragmentInteractionListener");
        }
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {

        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        rootView=inflater.inflate(R.layout.fragment_assignment2, container, false);

        return rootView;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        initializeView();

        callwebservice();
    }


    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }


    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.button_navigate:

                Map_Fragment_Info map_fragment_info=new Map_Fragment_Info();
                map_fragment_info.setLatitude(place_detailsList.get(selectedItem_spinner_place).getLocation().getLatitude());
                map_fragment_info.setLongitude(place_detailsList.get(selectedItem_spinner_place).getLocation().getLongitude());
                map_fragment_info.setName(place_detailsList.get(selectedItem_spinner_place).getName());

                mListener.onFragmentInteraction(Fragment_Tags_Constant.Map_Fragment,map_fragment_info);
                break;
        }


    }

    private void initializeView() {
        textView_car_val=(TextView)rootView.findViewById(R.id.textView_car_val);
        textView_train_val=(TextView)rootView.findViewById(R.id.textView_train_val);

        button_navigate=(Button)rootView.findViewById(R.id.button_navigate);
        button_navigate.setOnClickListener(this);
        spinner_place_selection=(Spinner)rootView.findViewById(R.id.spinner_place_selection);

        progressBar=(ProgressBar)rootView.findViewById(R.id.progressBar);

        parentView=(RelativeLayout)rootView.findViewById(R.id.parentView);
        parentView.setVisibility(View.GONE);

    }

    private void callwebservice() {

        progressBar.setVisibility(View.VISIBLE);

        String url = "http://express-it.optusnet.com.au/sample.json";


        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        //Parse response
                        Type listType = new TypeToken<ArrayList<Place_Details>>(){}.getType();
                        place_detailsList = new GsonBuilder().create().fromJson(response, listType);

                        if(place_detailsList!=null) {
                            responseAction();
                        }
                        else
                        {
                            progressBar.setVisibility(View.GONE);

                            //Here we can show snackbar to show error to user
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getActivity(), error.toString(), Toast.LENGTH_LONG).show();
                        progressBar.setVisibility(View.GONE);
                        //Here we can show snackbar to show error to user

                    }
                }) {

        };
        RequestQueue requestQueue = Volley.newRequestQueue(getActivity());
        requestQueue.add(stringRequest);

    }

    private void responseAction() {

        parentView.setVisibility(View.VISIBLE);
        progressBar.setVisibility(View.GONE);


        // Spinner element
        Place_Details_Spinner_Adapter adapter = new Place_Details_Spinner_Adapter(getActivity(),place_detailsList);
        adapter.setDropDownViewResource(android.R.layout.simple_list_item_single_choice);
        spinner_place_selection.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {
                selectedItem_spinner_place=position;

                textView_car_val.setText(place_detailsList.get(position).getFromcentral().getCar());
                textView_train_val.setText(place_detailsList.get(position).getFromcentral().getTrain());
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        spinner_place_selection.setAdapter(adapter);
    }



}
