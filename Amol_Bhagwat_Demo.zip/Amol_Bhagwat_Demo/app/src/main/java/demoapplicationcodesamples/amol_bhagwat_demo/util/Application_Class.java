package demoapplicationcodesamples.amol_bhagwat_demo.util;

import android.app.Application;


public class Application_Class extends Application{

    @Override
    public void onCreate()
    {
        super.onCreate();


    }




}
