package demoapplicationcodesamples.amol_bhagwat_demo.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import java.util.List;

import demoapplicationcodesamples.amol_bhagwat_demo.R;

/**
 * Created by Techteam on 3/8/2016.
 */
public class Recycler_Item_Adapter_Point1 extends RecyclerView.Adapter<Recycler_Item_Adapter_Point1.ViewHolder> {

   private List<String> items;
   private Context context;

    public Recycler_Item_Adapter_Point1(Context context, List<String> items) {
        this.context = context;
        this.items = items;

    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.point1_list_row, parent, false);

        return new ViewHolder(v);
    }


    @Override
    public void onBindViewHolder(final ViewHolder holder, final int position) {

        holder.textView_item.setText("ID: " + items.get(position));

    }


    @Override
    public int getItemCount() {
        return items.size();
    }



    public  class ViewHolder extends RecyclerView.ViewHolder {
        public TextView textView_item;

        public ViewHolder(View itemView) {
            super(itemView);
            textView_item = (TextView) itemView.findViewById(R.id.textView_item);
        }

    }
}