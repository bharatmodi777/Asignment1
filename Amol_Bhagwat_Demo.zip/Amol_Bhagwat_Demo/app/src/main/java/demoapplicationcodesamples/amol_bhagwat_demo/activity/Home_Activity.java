package demoapplicationcodesamples.amol_bhagwat_demo.activity;

import android.os.Bundle;
import android.support.design.widget.NavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import demoapplicationcodesamples.amol_bhagwat_demo.fragment.Assignment1_Fragment;
import demoapplicationcodesamples.amol_bhagwat_demo.fragment.Assignment2_Fragment;
import demoapplicationcodesamples.amol_bhagwat_demo.fragment.Map_Fragment;
import demoapplicationcodesamples.amol_bhagwat_demo.pojo.Map_Fragment_Info;
import demoapplicationcodesamples.amol_bhagwat_demo.modal.OnCustomFragmentInteractionListener;
import demoapplicationcodesamples.amol_bhagwat_demo.R;


public class Home_Activity extends AppCompatActivity implements OnCustomFragmentInteractionListener {

    private DrawerLayout drawerLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_screen_);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        final ActionBar ab = getSupportActionBar();
        ab.setHomeAsUpIndicator(R.drawable.ic_menu);
        ab.setDisplayHomeAsUpEnabled(true);


        drawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        if (navigationView != null) {
            setupDrawerContent(navigationView);
        }

        //initially open home fragment
        replaceFragment(R.id.assignment1);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                drawerLayout.openDrawer(GravityCompat.START);
                return true;
        }
        return super.onOptionsItemSelected(item);
    }


    private void setupDrawerContent(NavigationView navigationView) {
        navigationView.setNavigationItemSelectedListener(
                new NavigationView.OnNavigationItemSelectedListener() {
                    @Override
                    public boolean onNavigationItemSelected(MenuItem menuItem) {
                        menuItem.setChecked(true);
                        drawerLayout.closeDrawers();


                        //fragment replacer #
                        replaceFragment(menuItem.getItemId());
                        return true;
                    }
                });
    }


    private void replaceFragment(int itemId) {

        Fragment fragment = null;
        String title = getString(R.string.app_name);
        switch (itemId) {
            case R.id.assignment1:
                 fragment = Assignment1_Fragment.newInstance();
                 title = getString(R.string.assignment1);
                break;

            case R.id.assignment2:
                fragment = Assignment2_Fragment.newInstance();
                title = getString(R.string.assignment2);
                break;

            default:
                break;
        }

        replaceFragment(fragment,title);


    }

    private void replaceFragment(Fragment fragment,String title) {
        if (fragment != null) {
            FragmentManager fragmentManager = getSupportFragmentManager();
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.replace(R.id.container_body, fragment);
            fragmentTransaction.commit();

            // set the toolbar title
            getSupportActionBar().setTitle(title);
        }

    }


    @Override
    public void onFragmentInteraction(int fragmentID, Map_Fragment_Info map_fragment_info) {
        Fragment   fragment = Map_Fragment.newInstance(map_fragment_info);
        replaceFragment(fragment,getString(R.string.title_activity_maps));

        //Note----we can maintain fragment stack here by addToBackStack method as per our requirement
    }
}